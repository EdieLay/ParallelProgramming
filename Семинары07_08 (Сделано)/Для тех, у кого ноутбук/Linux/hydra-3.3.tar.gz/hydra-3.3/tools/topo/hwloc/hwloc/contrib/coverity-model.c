void bogus() {
   __coverity_panic__();
}
